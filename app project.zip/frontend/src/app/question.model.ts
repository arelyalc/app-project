export interface Question {
    question: String;
    answer: String;
    user_id: number;
}