export interface User {
    name: String;
    email: String;
    username: String;
    password: String;
    id?: number;
}