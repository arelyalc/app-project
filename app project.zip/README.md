# APP Project 
to run the backend, cd into backend folder and do npm install, then run  json-server --watch db.json

in another terminal, cd into frontend folder and do npm install, then run npm start